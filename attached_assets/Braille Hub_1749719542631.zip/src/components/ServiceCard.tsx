import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  onTryIt: () => void;
  gradient: string;
  customButton?: React.ReactNode;
}

const ServiceCard = ({ title, description, icon: Icon, onTryIt, gradient, customButton }: ServiceCardProps) => {
  return (
    <Card className="group hover:shadow-2xl transition-all duration-300 border-0 overflow-hidden" data-id="wybagxjsn" data-path="src/components/ServiceCard.tsx">
      <div className={`${gradient} p-1`} data-id="14cq5nnwf" data-path="src/components/ServiceCard.tsx">
        <CardHeader className="bg-white m-1 rounded-t-lg" data-id="0tgp1sd33" data-path="src/components/ServiceCard.tsx">
          <div className="flex items-center space-x-3" data-id="rrfbn7b55" data-path="src/components/ServiceCard.tsx">
            <div className="p-3 rounded-full bg-gradient-to-r from-blue-500 to-purple-600" data-id="2tsfyeff0" data-path="src/components/ServiceCard.tsx">
              <Icon className="h-6 w-6 text-white" data-id="kj6ucis93" data-path="src/components/ServiceCard.tsx" />
            </div>
            <div data-id="22bxcx87i" data-path="src/components/ServiceCard.tsx">
              <CardTitle className="text-xl font-bold text-gray-800" data-id="thyr5yfuq" data-path="src/components/ServiceCard.tsx">{title}</CardTitle>
            </div>
          </div>
        </CardHeader>
        <CardContent className="bg-white m-1 mb-0 rounded-b-lg" data-id="g1dl3rb3u" data-path="src/components/ServiceCard.tsx">
          <CardDescription className="text-gray-600 mb-4 leading-relaxed" data-id="i6ddc8ytr" data-path="src/components/ServiceCard.tsx">
            {description}
          </CardDescription>
          {customButton ?
          <div className="w-full" data-id="7cdutbw5v" data-path="src/components/ServiceCard.tsx">
              {customButton}
            </div> :

          <Button
            onClick={onTryIt}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-2 px-4 rounded-lg transform transition-transform hover:scale-105" data-id="x5ujyfokr" data-path="src/components/ServiceCard.tsx">
              Try It Now
            </Button>
          }
        </CardContent>
      </div>
    </Card>);

};

export default ServiceCard;