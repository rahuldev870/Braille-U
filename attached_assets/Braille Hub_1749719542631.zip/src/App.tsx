import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import HomePage from '@/pages/HomePage';
import TextToBraillePage from '@/pages/TextToBraillePage';
import ImageToBraillePage from '@/pages/ImageToBraillePage';
import BrailleToTextPage from '@/pages/BrailleToTextPage';
import ExternalBrailleToolPage from '@/pages/ExternalBrailleToolPage';
import AboutPage from '@/pages/AboutPage';
import NotFound from '@/pages/NotFound';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false
    }
  }
});

function App() {
  return (
    <QueryClientProvider client={queryClient} data-id="rooj39oni" data-path="src/App.tsx">
      <TooltipProvider data-id="m2feos371" data-path="src/App.tsx">
        <Router data-id="yn1vzkpdl" data-path="src/App.tsx">
          <div className="App" data-id="6qaa0cpl2" data-path="src/App.tsx">
            <Routes data-id="1z3dad3n5" data-path="src/App.tsx">
              <Route path="/" element={<HomePage data-id="o1m0qiacq" data-path="src/App.tsx" />} data-id="lguiu6sok" data-path="src/App.tsx" />
              <Route path="/text-to-braille" element={<TextToBraillePage data-id="3csabjt23" data-path="src/App.tsx" />} data-id="fhok1vhoc" data-path="src/App.tsx" />
              <Route path="/image-to-braille" element={<ImageToBraillePage data-id="tj8gbtw0l" data-path="src/App.tsx" />} data-id="2o1u30z2r" data-path="src/App.tsx" />
              <Route path="/braille-to-text" element={<BrailleToTextPage data-id="ruo54o3fj" data-path="src/App.tsx" />} data-id="er64ragdq" data-path="src/App.tsx" />
              <Route path="/external-braille-tool" element={<ExternalBrailleToolPage data-id="y88fv7vyx" data-path="src/App.tsx" />} data-id="c0mcyykwl" data-path="src/App.tsx" />
              <Route path="/about" element={<AboutPage data-id="dc34bn2bz" data-path="src/App.tsx" />} data-id="gxzaeddzv" data-path="src/App.tsx" />
              <Route path="*" element={<NotFound data-id="v9ht94390" data-path="src/App.tsx" />} data-id="xgeb26q59" data-path="src/App.tsx" />
            </Routes>
          </div>
          <Toaster data-id="7obwbo3gb" data-path="src/App.tsx" />
        </Router>
      </TooltipProvider>
    </QueryClientProvider>);

}

export default App;