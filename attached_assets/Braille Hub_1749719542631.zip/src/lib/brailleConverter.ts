// Comprehensive Braille converter with enhanced Hindi support including matras
const englishToBraille: {[key: string]: string;} = {
  // English letters
  'a': '⠁', 'b': '⠃', 'c': '⠉', 'd': '⠙', 'e': '⠑', 'f': '⠋', 'g': '⠛', 'h': '⠓', 'i': '⠊', 'j': '⠚',
  'k': '⠅', 'l': '⠇', 'm': '⠍', 'n': '⠝', 'o': '⠕', 'p': '⠏', 'q': '⠟', 'r': '⠗', 's': '⠎', 't': '⠞',
  'u': '⠥', 'v': '⠧', 'w': '⠺', 'x': '⠭', 'y': '⠽', 'z': '⠵',

  // Numbers
  '1': '⠼⠁', '2': '⠼⠃', '3': '⠼⠉', '4': '⠼⠙', '5': '⠼⠑',
  '6': '⠼⠋', '7': '⠼⠛', '8': '⠼⠓', '9': '⠼⠊', '0': '⠼⠚',

  // Punctuation
  '.': '⠲', ',': '⠂', '?': '⠦', '!': '⠖', ';': '⠆', ':': '⠒',
  '-': '⠤', '(': '⠷', ')': '⠾', ' ': ' ', '\n': '\n'
};

// Hindi Braille mapping including consonants, vowels, and matras
const hindiToBraille: {[key: string]: string;} = {
  // Hindi vowels (स्वर)
  'अ': '⠁', // a
  'आ': '⠜', // aa
  'इ': '⠊', // i
  'ई': '⠔', // ii
  'उ': '⠥', // u
  'ऊ': '⠳', // uu
  'ए': '⠑', // e
  'ऐ': '⠌', // ai
  'ओ': '⠕', // o
  'औ': '⠪', // au
  'ऋ': '⠐⠗', // ri
  'ॠ': '⠐⠗⠔', // rii

  // Hindi matras (vowel signs)
  'ा': '⠜', // aa matra
  'ि': '⠊', // i matra
  'ी': '⠔', // ii matra
  'ु': '⠥', // u matra
  'ू': '⠳', // uu matra
  'े': '⠑', // e matra
  'ै': '⠌', // ai matra
  'ो': '⠕', // o matra
  'ौ': '⠪', // au matra
  'ृ': '⠐⠗', // ri matra
  'ॄ': '⠐⠗⠔', // rii matra
  'ं': '⠰', // anusvara (bindu)
  'ः': '⠱', // visarga
  '्': '', // halant (virama) - often invisible in Braille

  // Hindi consonants (व्यंजन)
  'क': '⠅', // ka
  'ख': '⠨⠅', // kha
  'ग': '⠛', // ga
  'घ': '⠨⠛', // gha
  'ङ': '⠬', // nga

  'च': '⠉', // cha
  'छ': '⠨⠉', // chha
  'ज': '⠚', // ja
  'झ': '⠨⠚', // jha
  'ञ': '⠒', // nya

  'ट': '⠞', // ta (retroflex)
  'ठ': '⠨⠞', // tha (retroflex)
  'ड': '⠙', // da (retroflex)
  'ढ': '⠨⠙', // dha (retroflex)
  'ण': '⠝', // na (retroflex)

  'त': '⠞⠂', // ta (dental)
  'थ': '⠹', // tha (dental)
  'द': '⠙⠂', // da (dental)
  'ध': '⠮', // dha (dental)
  'न': '⠝⠂', // na (dental)

  'प': '⠏', // pa
  'फ': '⠨⠏', // pha
  'ब': '⠃', // ba
  'भ': '⠨⠃', // bha
  'म': '⠍', // ma

  'य': '⠽', // ya
  'र': '⠗', // ra
  'ल': '⠇', // la
  'व': '⠧', // va
  'श': '⠩', // sha
  'ष': '⠯', // sha (retroflex)
  'स': '⠎', // sa
  'ह': '⠓', // ha

  // Additional consonants
  'क्ष': '⠅⠩', // ksha
  'त्र': '⠞⠗', // tra
  'ज्ञ': '⠚⠒', // gya

  // Numbers in Devanagari
  '०': '⠼⠚', '१': '⠼⠁', '२': '⠼⠃', '③': '⠼⠉', '४': '⠼⠙',
  '५': '⠼⠑', '६': '⠼⠋', '७': '⠼⠛', '८': '⠼⠓', '९': '⠼⠊',

  // Punctuation marks
  '।': '⠲', // danda (Hindi full stop)
  '॥': '⠲⠲', // double danda
  '?': '⠦',
  '!': '⠖',
  ',': '⠂',
  ';': '⠆',
  ':': '⠒',
  '-': '⠤',
  '(': '⠷',
  ')': '⠾',
  ' ': ' ',
  '\n': '\n'
};

// Combine all mappings
const textToBrailleMap = { ...englishToBraille, ...hindiToBraille };

// Reverse mapping for Braille to text conversion
const brailleToTextMap = Object.fromEntries(
  Object.entries(textToBrailleMap).map(([key, value]) => [value, key])
);

export function convertTextToBraille(text: string): string {
  if (!text) return '';

  let result = '';
  let i = 0;

  while (i < text.length) {
    let char = text[i];
    let converted = false;

    // Handle multi-character sequences (like conjuncts)
    if (i < text.length - 1) {
      const twoChar = text.substr(i, 2);
      if (textToBrailleMap[twoChar]) {
        result += textToBrailleMap[twoChar];
        i += 2;
        converted = true;
      }
    }

    // Handle three-character sequences
    if (!converted && i < text.length - 2) {
      const threeChar = text.substr(i, 3);
      if (textToBrailleMap[threeChar]) {
        result += textToBrailleMap[threeChar];
        i += 3;
        converted = true;
      }
    }

    // Handle single character
    if (!converted) {
      const lowerChar = char.toLowerCase();
      if (textToBrailleMap[char]) {
        // Use original case for Hindi characters
        result += textToBrailleMap[char];
      } else if (textToBrailleMap[lowerChar]) {
        // Handle English case conversion
        const brailleChar = textToBrailleMap[lowerChar];
        result += char === char.toUpperCase() && char !== lowerChar ?
        '⠠' + brailleChar : brailleChar;
      } else {
        // Unknown character, keep as is
        result += char;
      }
      i++;
    }
  }

  return result;
}

export function getBrailleWithMapping(text: string): {braille: string;mapping: Array<{original: string;braille: string;}>;} {
  if (!text) return { braille: '', mapping: [] };

  const mapping: Array<{original: string;braille: string;}> = [];
  let result = '';
  let i = 0;

  while (i < text.length) {
    let char = text[i];
    let converted = false;

    // Handle multi-character sequences
    if (i < text.length - 1) {
      const twoChar = text.substr(i, 2);
      if (textToBrailleMap[twoChar]) {
        const brailleChar = textToBrailleMap[twoChar];
        result += brailleChar;
        mapping.push({ original: twoChar, braille: brailleChar });
        i += 2;
        converted = true;
      }
    }

    // Handle three-character sequences
    if (!converted && i < text.length - 2) {
      const threeChar = text.substr(i, 3);
      if (textToBrailleMap[threeChar]) {
        const brailleChar = textToBrailleMap[threeChar];
        result += brailleChar;
        mapping.push({ original: threeChar, braille: brailleChar });
        i += 3;
        converted = true;
      }
    }

    // Handle single character
    if (!converted) {
      const lowerChar = char.toLowerCase();
      if (textToBrailleMap[char]) {
        const brailleChar = textToBrailleMap[char];
        result += brailleChar;
        mapping.push({ original: char, braille: brailleChar });
      } else if (textToBrailleMap[lowerChar]) {
        const brailleChar = textToBrailleMap[lowerChar];
        const finalBraille = char === char.toUpperCase() && char !== lowerChar ?
        '⠠' + brailleChar : brailleChar;
        result += finalBraille;
        mapping.push({ original: char, braille: finalBraille });
      } else {
        result += char;
        mapping.push({ original: char, braille: char });
      }
      i++;
    }
  }

  return { braille: result, mapping };
}

export function isValidBrailleChar(char: string): boolean {
  const brailleRange = /[\u2800-\u28FF]/;
  return brailleRange.test(char) || char === ' ' || char === '\n';
}

export function convertBrailleToText(braille: string): string {
  if (!braille) return '';

  let result = '';
  let i = 0;

  while (i < braille.length) {
    let char = braille[i];

    // Handle multi-character Braille sequences
    if (i < braille.length - 1) {
      const twoChar = braille.substr(i, 2);
      if (brailleToTextMap[twoChar]) {
        result += brailleToTextMap[twoChar];
        i += 2;
        continue;
      }
    }

    if (i < braille.length - 2) {
      const threeChar = braille.substr(i, 3);
      if (brailleToTextMap[threeChar]) {
        result += brailleToTextMap[threeChar];
        i += 3;
        continue;
      }
    }

    // Handle single character
    if (brailleToTextMap[char]) {
      result += brailleToTextMap[char];
    } else {
      result += char;
    }
    i++;
  }

  return result;
}