import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Volume2, Mic, MicOff, Copy, Download, ArrowLeft, Home, RefreshCw, AlertCircle, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';
import { useTextToSpeech } from '@/hooks/useTextToSpeech';
import { convertTextToBraille, getBrailleWithMapping } from '@/lib/brailleConverter';
import { useToast } from '@/hooks/use-toast';

const TextToBraillePage: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [brailleOutput, setBrailleOutput] = useState('');
  const [characterMapping, setCharacterMapping] = useState<Array<{original: string;braille: string;}>>([]);
  const [micPermissionDenied, setMicPermissionDenied] = useState(false);
  const [showSpeechError, setShowSpeechError] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();

  const {
    isListening,
    hasRecognitionSupport,
    startListening,
    stopListening,
    error: speechError
  } = useSpeechRecognition({
    onResult: (transcript) => {
      console.log('Speech recognition result:', transcript);
      setInputText((prev) => prev + ' ' + transcript);
      handleConvert(inputText + ' ' + transcript);
      setShowSpeechError(false);
      setMicPermissionDenied(false);

      toast({
        title: "Speech Recognized",
        description: "Text has been added to the input field."
      });
    },
    onError: (error) => {
      console.error('Speech recognition error:', error);
      setShowSpeechError(true);

      if (error.includes('denied') || error.includes('not-allowed')) {
        setMicPermissionDenied(true);
      }

      toast({
        title: "Speech Recognition Error",
        description: error,
        variant: "destructive"
      });
    },
    lang: 'en-US',
    continuous: false,
    interimResults: false
  });

  const { speak, isSpeaking } = useTextToSpeech();

  const handleConvert = (text = inputText) => {
    if (!text.trim()) {
      setBrailleOutput('');
      setCharacterMapping([]);
      return;
    }

    try {
      const { braille, mapping } = getBrailleWithMapping(text);
      setBrailleOutput(braille);
      setCharacterMapping(mapping);
    } catch (error) {
      console.error('Conversion error:', error);
      toast({
        title: "Conversion Error",
        description: "Failed to convert text to Braille. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleCopy = async () => {
    if (!brailleOutput) {
      toast({
        title: "Nothing to Copy",
        description: "Please convert some text to Braille first.",
        variant: "destructive"
      });
      return;
    }

    try {
      await navigator.clipboard.writeText(brailleOutput);
      toast({
        title: "Success",
        description: "Braille text copied to clipboard!"
      });
    } catch (error) {
      console.error('Copy error:', error);
      toast({
        title: "Copy Failed",
        description: "Failed to copy text to clipboard. Please select and copy manually.",
        variant: "destructive"
      });
    }
  };

  const handleDownload = () => {
    if (!brailleOutput) {
      toast({
        title: "Nothing to Download",
        description: "Please convert some text to Braille first.",
        variant: "destructive"
      });
      return;
    }

    try {
      const element = document.createElement('a');
      const file = new Blob([brailleOutput], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = 'braille-output.txt';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);

      toast({
        title: "Success",
        description: "Braille text downloaded successfully!"
      });
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: "Download Failed",
        description: "Failed to download the file. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleSpeak = () => {
    if (!inputText.trim()) {
      toast({
        title: "Nothing to Speak",
        description: "Please enter some text first.",
        variant: "destructive"
      });
      return;
    }

    try {
      speak(inputText);
    } catch (error) {
      console.error('Text-to-speech error:', error);
      toast({
        title: "Speech Error",
        description: "Failed to speak the text. Please try again.",
        variant: "destructive"
      });
    }
  };

  const clearAll = () => {
    setInputText('');
    setBrailleOutput('');
    setCharacterMapping([]);
    setShowSpeechError(false);
    setMicPermissionDenied(false);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }

    toast({
      title: "Cleared",
      description: "All content has been cleared."
    });
  };

  const handleSpeechToggle = () => {
    if (isListening) {
      stopListening();
    } else {
      if (!hasRecognitionSupport) {
        toast({
          title: "Not Supported",
          description: "Speech recognition is not supported in this browser. Please try Chrome, Edge, or Safari.",
          variant: "destructive"
        });
        return;
      }
      startListening();
    }
  };

  const dismissSpeechError = () => {
    setShowSpeechError(false);
    setMicPermissionDenied(false);
  };

  const requestMicPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((track) => track.stop());
      setMicPermissionDenied(false);
      setShowSpeechError(false);
      toast({
        title: "Permission Granted",
        description: "Microphone access granted! You can now use voice input."
      });
    } catch (error) {
      console.error('Microphone permission error:', error);
      toast({
        title: "Permission Denied",
        description: "Please allow microphone access in your browser settings to use voice input.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 py-8 px-4" data-id="s3r57y72r" data-path="src/pages/TextToBraillePage.tsx">
      <div className="max-w-4xl mx-auto" data-id="mr01th93r" data-path="src/pages/TextToBraillePage.tsx">
        {/* Header with Back Button */}
        <div className="flex items-center justify-between mb-8" data-id="h67w39859" data-path="src/pages/TextToBraillePage.tsx">
          <div className="flex items-center gap-4" data-id="1xc449sc5" data-path="src/pages/TextToBraillePage.tsx">
            <Link to="/" data-id="emy6a4v33" data-path="src/pages/TextToBraillePage.tsx">
              <Button variant="outline" size="sm" className="flex items-center gap-2" data-id="go4fmr5qa" data-path="src/pages/TextToBraillePage.tsx">
                <ArrowLeft className="h-4 w-4" data-id="xeg41i01x" data-path="src/pages/TextToBraillePage.tsx" />
                Back
              </Button>
            </Link>
            <Link to="/" data-id="60w3rxhxs" data-path="src/pages/TextToBraillePage.tsx">
              <Button variant="ghost" size="sm" className="flex items-center gap-2" data-id="gej2c1g7a" data-path="src/pages/TextToBraillePage.tsx">
                <Home className="h-4 w-4" data-id="3o087l8jp" data-path="src/pages/TextToBraillePage.tsx" />
                Home
              </Button>
            </Link>
          </div>
          <Button
            onClick={clearAll}
            variant="outline"
            size="sm"
            className="flex items-center gap-2" data-id="2ulh2bame" data-path="src/pages/TextToBraillePage.tsx">
            <RefreshCw className="h-4 w-4" data-id="aqj2uq2k1" data-path="src/pages/TextToBraillePage.tsx" />
            Clear All
          </Button>
        </div>

        <div className="text-center mb-8" data-id="6sdupemd9" data-path="src/pages/TextToBraillePage.tsx">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4" data-id="cxbwf1w81" data-path="src/pages/TextToBraillePage.tsx">
            Text to Braille Converter
          </h1>
          <p className="text-gray-600 text-lg" data-id="sdj5bufll" data-path="src/pages/TextToBraillePage.tsx">
            Convert text to Braille dots with enhanced support for Hindi including matras (vowel signs)
          </p>
        </div>

        {/* Enhanced Speech Recognition Error Display */}
        {(speechError || showSpeechError) &&
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg" data-id="3oi8smm43" data-path="src/pages/TextToBraillePage.tsx">
            <div className="flex items-start justify-between gap-3" data-id="xb478d2l6" data-path="src/pages/TextToBraillePage.tsx">
              <div className="flex items-start gap-3" data-id="8gr710daa" data-path="src/pages/TextToBraillePage.tsx">
                <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" data-id="60kar3umb" data-path="src/pages/TextToBraillePage.tsx" />
                <div data-id="m36xnxsj8" data-path="src/pages/TextToBraillePage.tsx">
                  <h4 className="font-semibold text-red-800" data-id="dbisb9q58" data-path="src/pages/TextToBraillePage.tsx">Speech Recognition Issue</h4>
                  <p className="text-red-700 text-sm" data-id="9lln2x8m9" data-path="src/pages/TextToBraillePage.tsx">
                    {micPermissionDenied ?
                  "Microphone access denied. Please allow microphone access and try again." :
                  speechError || "Speech recognition error occurred. Please try again."}
                  </p>
                  {micPermissionDenied &&
                <div className="mt-3 space-y-2" data-id="s900qqmw2" data-path="src/pages/TextToBraillePage.tsx">
                      <Button
                    onClick={requestMicPermission}
                    size="sm"
                    className="bg-red-600 hover:bg-red-700 text-white" data-id="zyeoyo2hy" data-path="src/pages/TextToBraillePage.tsx">
                        Grant Microphone Access
                      </Button>
                      <p className="text-xs text-red-600" data-id="6zei364q3" data-path="src/pages/TextToBraillePage.tsx">
                        You may need to click the microphone icon in your address bar or check browser settings.
                      </p>
                    </div>
                }
                </div>
              </div>
              <Button
              onClick={dismissSpeechError}
              variant="ghost"
              size="sm"
              className="text-red-600 hover:text-red-800 hover:bg-red-100" data-id="ejchiu7av" data-path="src/pages/TextToBraillePage.tsx">
                <X className="h-4 w-4" data-id="zpva4huik" data-path="src/pages/TextToBraillePage.tsx" />
              </Button>
            </div>
          </div>
        }

        <div className="grid md:grid-cols-2 gap-8" data-id="cdop0uxhc" data-path="src/pages/TextToBraillePage.tsx">
          {/* Input Section */}
          <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm" data-id="9m2mxamoe" data-path="src/pages/TextToBraillePage.tsx">
            <CardHeader data-id="x0qmp0jt6" data-path="src/pages/TextToBraillePage.tsx">
              <CardTitle className="flex items-center gap-2" data-id="bmd5qf0b8" data-path="src/pages/TextToBraillePage.tsx">
                Input Text
                <div className="flex gap-2 ml-auto" data-id="t3jiwxz6f" data-path="src/pages/TextToBraillePage.tsx">
                  {hasRecognitionSupport &&
                  <Button
                    onClick={handleSpeechToggle}
                    variant={isListening ? "destructive" : "outline"}
                    size="sm"
                    className={isListening ? "animate-pulse" : ""}
                    title={micPermissionDenied ? "Microphone access needed" : "Voice input"} data-id="vwp8zkxqz" data-path="src/pages/TextToBraillePage.tsx">
                      {isListening ? <MicOff className="h-4 w-4" data-id="8iwvfpum5" data-path="src/pages/TextToBraillePage.tsx" /> : <Mic className="h-4 w-4" data-id="gqjboe3ok" data-path="src/pages/TextToBraillePage.tsx" />}
                    </Button>
                  }
                  <Button
                    onClick={handleSpeak}
                    variant="outline"
                    size="sm"
                    disabled={!inputText.trim() || isSpeaking} data-id="h0gfoo3oa" data-path="src/pages/TextToBraillePage.tsx">
                    <Volume2 className="h-4 w-4" data-id="na7ws6fgx" data-path="src/pages/TextToBraillePage.tsx" />
                  </Button>
                </div>
              </CardTitle>
              <CardDescription data-id="fjhprktg7" data-path="src/pages/TextToBraillePage.tsx">
                Type or speak your text in English or Hindi. Hindi matras will be properly converted.
                {!hasRecognitionSupport &&
                <span className="block text-amber-600 mt-1" data-id="ompzfadn7" data-path="src/pages/TextToBraillePage.tsx">
                    Speech recognition not supported in this browser.
                  </span>
                }
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4" data-id="ia3et0ohz" data-path="src/pages/TextToBraillePage.tsx">
              <Textarea
                ref={textareaRef}
                placeholder="Enter text to convert to Braille... (supports Hindi with matras)"
                value={inputText}
                onChange={(e) => {
                  setInputText(e.target.value);
                  handleConvert(e.target.value);
                }}
                className="min-h-[200px] text-lg" data-id="y69ea3wfs" data-path="src/pages/TextToBraillePage.tsx" />

              {isListening &&
              <div className="text-center" data-id="ndin1bhzd" data-path="src/pages/TextToBraillePage.tsx">
                  <div className="inline-flex items-center gap-2 text-red-600 animate-pulse" data-id="yxcy953gj" data-path="src/pages/TextToBraillePage.tsx">
                    <div className="w-2 h-2 bg-red-600 rounded-full animate-ping" data-id="u7p0mdbap" data-path="src/pages/TextToBraillePage.tsx"></div>
                    Listening... Speak now
                    <div className="w-2 h-2 bg-red-600 rounded-full animate-ping" data-id="jzi8g5d4g" data-path="src/pages/TextToBraillePage.tsx"></div>
                  </div>
                  <p className="text-sm text-gray-500 mt-1" data-id="t5dymzd5t" data-path="src/pages/TextToBraillePage.tsx">Click the microphone again to stop</p>
                </div>
              }

              {/* Enhanced Speech Recognition Tips */}
              {hasRecognitionSupport && !isListening && !showSpeechError &&
              <div className="bg-blue-50 rounded-lg p-3" data-id="8wxet3jw3" data-path="src/pages/TextToBraillePage.tsx">
                  <h4 className="font-semibold text-blue-800 text-sm mb-1" data-id="aqjxs80vx" data-path="src/pages/TextToBraillePage.tsx">Speech Recognition Tips:</h4>
                  <ul className="text-xs text-blue-700 space-y-1" data-id="byyxe2ym6" data-path="src/pages/TextToBraillePage.tsx">
                    <li data-id="3y30ox5uu" data-path="src/pages/TextToBraillePage.tsx">• Speak clearly and at a normal pace</li>
                    <li data-id="sdyvjht28" data-path="src/pages/TextToBraillePage.tsx">• Make sure your microphone is working</li>
                    <li data-id="s2ob5aoqe" data-path="src/pages/TextToBraillePage.tsx">• Allow microphone access when prompted</li>
                    <li data-id="vyteyto5v" data-path="src/pages/TextToBraillePage.tsx">• Works best in quiet environments</li>
                    <li data-id="c1dfk8vf3" data-path="src/pages/TextToBraillePage.tsx">• Chrome, Edge, and Safari work best</li>
                  </ul>
                </div>
              }
            </CardContent>
          </Card>

          {/* Output Section */}
          <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm" data-id="px0s1a2sk" data-path="src/pages/TextToBraillePage.tsx">
            <CardHeader data-id="17ud2e4ri" data-path="src/pages/TextToBraillePage.tsx">
              <CardTitle className="flex items-center gap-2" data-id="ax6kq2i5y" data-path="src/pages/TextToBraillePage.tsx">
                Braille Output
                <div className="flex gap-2 ml-auto" data-id="5vhwu4pht" data-path="src/pages/TextToBraillePage.tsx">
                  <Button
                    onClick={handleCopy}
                    variant="outline"
                    size="sm"
                    disabled={!brailleOutput} data-id="ts993b7rv" data-path="src/pages/TextToBraillePage.tsx">
                    <Copy className="h-4 w-4" data-id="uk03xlgcf" data-path="src/pages/TextToBraillePage.tsx" />
                  </Button>
                  <Button
                    onClick={handleDownload}
                    variant="outline"
                    size="sm"
                    disabled={!brailleOutput} data-id="cus4xarqz" data-path="src/pages/TextToBraillePage.tsx">
                    <Download className="h-4 w-4" data-id="95tdgbz5y" data-path="src/pages/TextToBraillePage.tsx" />
                  </Button>
                </div>
              </CardTitle>
              <CardDescription data-id="jflaxc51m" data-path="src/pages/TextToBraillePage.tsx">
                Braille representation with proper handling of Hindi matras
              </CardDescription>
            </CardHeader>
            <CardContent data-id="77e5k0wf5" data-path="src/pages/TextToBraillePage.tsx">
              <div className="min-h-[200px] p-4 border rounded-lg bg-gray-50" data-id="9tyczdso5" data-path="src/pages/TextToBraillePage.tsx">
                <div className="text-4xl font-mono leading-relaxed break-all" data-id="nbkllag37" data-path="src/pages/TextToBraillePage.tsx">
                  {brailleOutput || 'Braille output will appear here...'}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Character Mapping */}
        {characterMapping.length > 0 &&
        <Card className="mt-8 shadow-lg border-0 bg-white/80 backdrop-blur-sm" data-id="3hexx0rrd" data-path="src/pages/TextToBraillePage.tsx">
            <CardHeader data-id="zfzr7fh9d" data-path="src/pages/TextToBraillePage.tsx">
              <CardTitle data-id="d22zoe64a" data-path="src/pages/TextToBraillePage.tsx">Character Mapping</CardTitle>
              <CardDescription data-id="e2tcs36ie" data-path="src/pages/TextToBraillePage.tsx">
                See how each character (including Hindi matras) maps to Braille
              </CardDescription>
            </CardHeader>
            <CardContent data-id="98cwb8sn5" data-path="src/pages/TextToBraillePage.tsx">
              <div className="grid gap-2 max-h-60 overflow-y-auto" data-id="k6kylk70t" data-path="src/pages/TextToBraillePage.tsx">
                {characterMapping.map((item, index) =>
              <div
                key={index}
                className="flex items-center justify-between p-2 bg-gray-50 rounded-lg" data-id="ilse3v07z" data-path="src/pages/TextToBraillePage.tsx">
                    <span className="text-lg font-medium" data-id="4j0eig57n" data-path="src/pages/TextToBraillePage.tsx">{item.original}</span>
                    <span className="text-2xl font-mono" data-id="d37crmrhn" data-path="src/pages/TextToBraillePage.tsx">{item.braille}</span>
                  </div>
              )}
              </div>
            </CardContent>
          </Card>
        }

        {/* Feature Information */}
        <Card className="mt-8 shadow-lg border-0 bg-gradient-to-r from-blue-50 to-purple-50" data-id="z1zcktf67" data-path="src/pages/TextToBraillePage.tsx">
          <CardContent className="pt-6" data-id="yzox0021s" data-path="src/pages/TextToBraillePage.tsx">
            <div className="grid md:grid-cols-3 gap-6 text-center" data-id="x2eb7yrke" data-path="src/pages/TextToBraillePage.tsx">
              <div data-id="jzrw1dvba" data-path="src/pages/TextToBraillePage.tsx">
                <div className="text-3xl mb-2" data-id="frl3vg2e7" data-path="src/pages/TextToBraillePage.tsx">🎤</div>
                <h3 className="font-semibold mb-1" data-id="u3979cjmt" data-path="src/pages/TextToBraillePage.tsx">Voice Input</h3>
                <p className="text-sm text-gray-600" data-id="u1srl12qq" data-path="src/pages/TextToBraillePage.tsx">
                  Use speech recognition for hands-free text input
                </p>
              </div>
              <div data-id="djovqw90u" data-path="src/pages/TextToBraillePage.tsx">
                <div className="text-3xl mb-2" data-id="sk3mawli9" data-path="src/pages/TextToBraillePage.tsx">🔊</div>
                <h3 className="font-semibold mb-1" data-id="jk98uvbhc" data-path="src/pages/TextToBraillePage.tsx">Audio Playback</h3>
                <p className="text-sm text-gray-600" data-id="7pe0cz30u" data-path="src/pages/TextToBraillePage.tsx">
                  Listen to your input text with text-to-speech
                </p>
              </div>
              <div data-id="xdgmo9fag" data-path="src/pages/TextToBraillePage.tsx">
                <div className="text-3xl mb-2" data-id="nfw31co7v" data-path="src/pages/TextToBraillePage.tsx">🇮🇳</div>
                <h3 className="font-semibold mb-1" data-id="rx0hkf92v" data-path="src/pages/TextToBraillePage.tsx">Hindi Support</h3>
                <p className="text-sm text-gray-600" data-id="u7a5ur7hh" data-path="src/pages/TextToBraillePage.tsx">
                  Full support for Hindi text including matras and conjuncts
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>);

};

export default TextToBraillePage;