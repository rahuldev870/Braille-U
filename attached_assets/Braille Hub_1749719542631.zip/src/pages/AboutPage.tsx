import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, Users, Accessibility, Globe, ArrowLeft, Home } from 'lucide-react';
import { Link } from 'react-router-dom';

const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 py-8 px-4" data-id="kdsds2wp4" data-path="src/pages/AboutPage.tsx">
      <div className="max-w-4xl mx-auto" data-id="s1mlkeum9" data-path="src/pages/AboutPage.tsx">
        {/* Header with Back Button */}
        <div className="flex items-center justify-between mb-8" data-id="vwmnbpy6k" data-path="src/pages/AboutPage.tsx">
          <div className="flex items-center gap-4" data-id="hdm8ctz87" data-path="src/pages/AboutPage.tsx">
            <Link to="/" data-id="sx8mh4jox" data-path="src/pages/AboutPage.tsx">
              <Button variant="outline" size="sm" className="flex items-center gap-2" data-id="0qoec37te" data-path="src/pages/AboutPage.tsx">
                <ArrowLeft className="h-4 w-4" data-id="073pxv29w" data-path="src/pages/AboutPage.tsx" />
                Back
              </Button>
            </Link>
            <Link to="/" data-id="vrtaivq1e" data-path="src/pages/AboutPage.tsx">
              <Button variant="ghost" size="sm" className="flex items-center gap-2" data-id="0cmi14zsr" data-path="src/pages/AboutPage.tsx">
                <Home className="h-4 w-4" data-id="vzh4cfj7s" data-path="src/pages/AboutPage.tsx" />
                Home
              </Button>
            </Link>
          </div>
        </div>

        <div className="text-center mb-12" data-id="ak9xlchry" data-path="src/pages/AboutPage.tsx">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent mb-4" data-id="ytva39ee9" data-path="src/pages/AboutPage.tsx">
            About Braille Bridge
          </h1>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto" data-id="178fjckiv" data-path="src/pages/AboutPage.tsx">
            Empowering accessibility through innovative Braille conversion technology, 
            with special focus on multilingual support including Hindi.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12" data-id="qz232nin2" data-path="src/pages/AboutPage.tsx">
          <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm" data-id="2ybnksy0m" data-path="src/pages/AboutPage.tsx">
            <CardHeader data-id="uhcin9krt" data-path="src/pages/AboutPage.tsx">
              <CardTitle className="flex items-center gap-2" data-id="12aq50hdz" data-path="src/pages/AboutPage.tsx">
                <Heart className="h-5 w-5 text-red-500" data-id="rivm7tu3r" data-path="src/pages/AboutPage.tsx" />
                Our Mission
              </CardTitle>
            </CardHeader>
            <CardContent data-id="cu5whdk8r" data-path="src/pages/AboutPage.tsx">
              <p className="text-gray-700" data-id="rvd9q5g7s" data-path="src/pages/AboutPage.tsx">
                To bridge the gap between visual and tactile reading by providing 
                accessible, accurate, and comprehensive Braille conversion tools. 
                We believe that information should be accessible to everyone, 
                regardless of visual ability.
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm" data-id="kuzxrgdda" data-path="src/pages/AboutPage.tsx">
            <CardHeader data-id="l0kgupv30" data-path="src/pages/AboutPage.tsx">
              <CardTitle className="flex items-center gap-2" data-id="uthjc7kv6" data-path="src/pages/AboutPage.tsx">
                <Accessibility className="h-5 w-5 text-blue-500" data-id="ak6giu0fr" data-path="src/pages/AboutPage.tsx" />
                Accessibility First
              </CardTitle>
            </CardHeader>
            <CardContent data-id="3c5nqr280" data-path="src/pages/AboutPage.tsx">
              <p className="text-gray-700" data-id="xis4bqcjm" data-path="src/pages/AboutPage.tsx">
                Every feature is designed with accessibility in mind. From voice 
                input to audio output, we ensure that our tools are usable by 
                people with varying abilities and preferences.
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-12 shadow-lg border-0 bg-white/80 backdrop-blur-sm" data-id="7r64tzk2x" data-path="src/pages/AboutPage.tsx">
          <CardHeader data-id="ema715klv" data-path="src/pages/AboutPage.tsx">
            <CardTitle className="flex items-center gap-2" data-id="n6yww1bub" data-path="src/pages/AboutPage.tsx">
              <Globe className="h-5 w-5 text-green-500" data-id="yc84gw5zu" data-path="src/pages/AboutPage.tsx" />
              Enhanced Hindi Support
            </CardTitle>
            <CardDescription data-id="c7a6befn7" data-path="src/pages/AboutPage.tsx">
              Breaking language barriers in Braille conversion
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4" data-id="gdwq95tfj" data-path="src/pages/AboutPage.tsx">
            <p className="text-gray-700" data-id="64pt1adj3" data-path="src/pages/AboutPage.tsx">
              Our platform provides comprehensive support for Hindi text conversion, 
              including proper handling of matras (vowel signs) and conjunct characters. 
              This ensures that Hindi readers can access accurate Braille representations 
              of their language.
            </p>
            
            <div className="bg-gradient-to-r from-orange-50 to-green-50 rounded-lg p-4" data-id="2tdwuw5no" data-path="src/pages/AboutPage.tsx">
              <h4 className="font-semibold text-gray-800 mb-2" data-id="1tpvpbj60" data-path="src/pages/AboutPage.tsx">Hindi Features Include:</h4>
              <ul className="list-disc list-inside space-y-1 text-gray-700 text-sm" data-id="gyszwngsn" data-path="src/pages/AboutPage.tsx">
                <li data-id="6iplyd69u" data-path="src/pages/AboutPage.tsx">Complete Devanagari script support</li>
                <li data-id="g2hgm79te" data-path="src/pages/AboutPage.tsx">Accurate matra (vowel sign) conversion</li>
                <li data-id="9kv9bm1mt" data-path="src/pages/AboutPage.tsx">Conjunct character recognition</li>
                <li data-id="o5xh4h327" data-path="src/pages/AboutPage.tsx">Proper handling of Unicode Hindi text</li>
                <li data-id="15db93bi9" data-path="src/pages/AboutPage.tsx">Support for mixed Hindi-English content</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-3 gap-6 mb-12" data-id="5t81xpsw6" data-path="src/pages/AboutPage.tsx">
          <Card className="shadow-lg border-0 bg-gradient-to-br from-blue-50 to-indigo-50" data-id="ezmrgdvj2" data-path="src/pages/AboutPage.tsx">
            <CardContent className="pt-6 text-center" data-id="vxbwc1pmo" data-path="src/pages/AboutPage.tsx">
              <div className="text-4xl mb-4" data-id="f3l8k3et7" data-path="src/pages/AboutPage.tsx">🎤</div>
              <h3 className="font-semibold mb-2" data-id="og85ojh3l" data-path="src/pages/AboutPage.tsx">Voice Recognition</h3>
              <p className="text-sm text-gray-600" data-id="l990g9o21" data-path="src/pages/AboutPage.tsx">
                Advanced speech-to-text technology for hands-free input
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-0 bg-gradient-to-br from-green-50 to-blue-50" data-id="rtgk280ve" data-path="src/pages/AboutPage.tsx">
            <CardContent className="pt-6 text-center" data-id="s322eoqop" data-path="src/pages/AboutPage.tsx">
              <div className="text-4xl mb-4" data-id="azfk9vlqn" data-path="src/pages/AboutPage.tsx">📸</div>
              <h3 className="font-semibold mb-2" data-id="f6jmh6oei" data-path="src/pages/AboutPage.tsx">OCR Technology</h3>
              <p className="text-sm text-gray-600" data-id="fvjt48iap" data-path="src/pages/AboutPage.tsx">
                Optical character recognition for extracting text from images
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-0 bg-gradient-to-br from-purple-50 to-pink-50" data-id="bavh75h0k" data-path="src/pages/AboutPage.tsx">
            <CardContent className="pt-6 text-center" data-id="prkbkd57z" data-path="src/pages/AboutPage.tsx">
              <div className="text-4xl mb-4" data-id="bs8e1yuie" data-path="src/pages/AboutPage.tsx">🔊</div>
              <h3 className="font-semibold mb-2" data-id="umdrtxxzp" data-path="src/pages/AboutPage.tsx">Audio Feedback</h3>
              <p className="text-sm text-gray-600" data-id="n3u9rf2w9" data-path="src/pages/AboutPage.tsx">
                Text-to-speech functionality for auditory confirmation
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8 shadow-lg border-0 bg-gradient-to-r from-indigo-100 to-purple-100" data-id="rifm3dewk" data-path="src/pages/AboutPage.tsx">
          <CardHeader data-id="rvnazi3f9" data-path="src/pages/AboutPage.tsx">
            <CardTitle className="flex items-center gap-2" data-id="ks6ijywrr" data-path="src/pages/AboutPage.tsx">
              <Users className="h-5 w-5 text-purple-600" data-id="v2gcs7r25" data-path="src/pages/AboutPage.tsx" />
              Who We Serve
            </CardTitle>
          </CardHeader>
          <CardContent data-id="vx991apr1" data-path="src/pages/AboutPage.tsx">
            <div className="grid md:grid-cols-2 gap-6" data-id="s8vueh7yb" data-path="src/pages/AboutPage.tsx">
              <div data-id="tz5h0y51u" data-path="src/pages/AboutPage.tsx">
                <h4 className="font-semibold mb-2" data-id="l586ezrnr" data-path="src/pages/AboutPage.tsx">Individuals</h4>
                <ul className="text-sm text-gray-700 space-y-1" data-id="d2mejoga2" data-path="src/pages/AboutPage.tsx">
                  <li data-id="sm6znyiu4" data-path="src/pages/AboutPage.tsx">• People learning Braille</li>
                  <li data-id="iigjecca7" data-path="src/pages/AboutPage.tsx">• Braille readers and writers</li>
                  <li data-id="5fjnbk6by" data-path="src/pages/AboutPage.tsx">• Students and educators</li>
                  <li data-id="oaeiqx6fd" data-path="src/pages/AboutPage.tsx">• Hindi language speakers</li>
                </ul>
              </div>
              <div data-id="x0cdb76aw" data-path="src/pages/AboutPage.tsx">
                <h4 className="font-semibold mb-2" data-id="whhq07mmy" data-path="src/pages/AboutPage.tsx">Organizations</h4>
                <ul className="text-sm text-gray-700 space-y-1" data-id="lcvker0sf" data-path="src/pages/AboutPage.tsx">
                  <li data-id="k5nlplqxc" data-path="src/pages/AboutPage.tsx">• Educational institutions</li>
                  <li data-id="y0vr0yzbc" data-path="src/pages/AboutPage.tsx">• Accessibility organizations</li>
                  <li data-id="q1j5ruc34" data-path="src/pages/AboutPage.tsx">• Libraries and resource centers</li>
                  <li data-id="cwzkp8zh0" data-path="src/pages/AboutPage.tsx">• Healthcare providers</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center" data-id="539e8e59z" data-path="src/pages/AboutPage.tsx">
          <h2 className="text-2xl font-bold text-gray-800 mb-4" data-id="26zkyurow" data-path="src/pages/AboutPage.tsx">
            Ready to Get Started?
          </h2>
          <p className="text-gray-600 mb-6" data-id="1yxx7g5so" data-path="src/pages/AboutPage.tsx">
            Explore our Braille conversion tools and experience the difference 
            that comprehensive language support makes.
          </p>
          <div className="flex flex-wrap justify-center gap-4" data-id="4qyhbhn4w" data-path="src/pages/AboutPage.tsx">
            <Link to="/text-to-braille" data-id="x5imcn58r" data-path="src/pages/AboutPage.tsx">
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600" data-id="x7fr8gkr4" data-path="src/pages/AboutPage.tsx">
                Text to Braille
              </Button>
            </Link>
            <Link to="/image-to-braille" data-id="htoto4yfq" data-path="src/pages/AboutPage.tsx">
              <Button size="lg" variant="outline" data-id="0l7c41608" data-path="src/pages/AboutPage.tsx">
                Image to Braille
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>);

};

export default AboutPage;