import { Button } from '@/components/ui/button';
import ServiceCard from '@/components/ServiceCard';
import { Type, Image, Camera, ArrowRight, Shield, Zap, Users, Globe } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
  const navigate = useNavigate();

  const handleBrailleImageToText = () => {
    // Navigate to our new external tool page instead of directly opening the external link
    navigate('/external-braille-tool');
  };

  const services = [
  {
    title: 'Text to Braille',
    description: 'Convert any text to Braille with voice input support. Speak or type your text and get instant Braille conversion with audio feedback.',
    icon: Type,
    gradient: 'bg-gradient-to-br from-blue-400 to-purple-600',
    path: '/text-to-braille'
  },
  {
    title: 'Image to Braille',
    description: 'Upload images containing text and convert them to Braille. Supports both English and Hindi text recognition with OCR technology.',
    icon: Image,
    gradient: 'bg-gradient-to-br from-green-400 to-blue-600',
    path: '/image-to-braille'
  },
  {
    title: 'Braille to Speech Converter',
    description: 'Use our external specialized tool to convert Braille patterns and images to speech. Advanced processing with easy navigation back to our services.',
    icon: Camera,
    gradient: 'bg-gradient-to-br from-orange-400 to-red-600',
    isExternal: true,
    onTryIt: handleBrailleImageToText,
    customButton:
    <button
      className="btn btn-primary mt-3 w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-semibold py-3 px-4 rounded-lg transform transition-transform hover:scale-105 border-0 outline-0"
      onClick={() => window.location.href = 'https://braille-speech-converter.onrender.com'}
      style={{
        background: 'linear-gradient(to right, #f97316, #dc2626)',
        border: 'none',
        outline: 'none',
        cursor: 'pointer'
      }} data-id="g5vruxock" data-path="src/pages/HomePage.tsx">

        Try It Now
      </button>

  }];


  const features = [
  {
    icon: Shield,
    title: 'Privacy First',
    description: 'All processing happens locally in your browser. Your data stays private and secure.'
  },
  {
    icon: Zap,
    title: 'Instant Conversion',
    description: 'Real-time text to Braille conversion with immediate visual and audio feedback.'
  },
  {
    icon: Users,
    title: 'Accessibility Focused',
    description: 'Designed with accessibility in mind, featuring keyboard navigation and screen reader support.'
  },
  {
    icon: Globe,
    title: 'Multi-Language',
    description: 'Support for both English and Hindi text recognition and Braille conversion.'
  }];


  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50" data-id="v70p5ni6k" data-path="src/pages/HomePage.tsx">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50" data-id="vw3m2l14l" data-path="src/pages/HomePage.tsx">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-id="4w0wq2uq3" data-path="src/pages/HomePage.tsx">
          <div className="flex justify-between items-center py-4" data-id="gxvxu0b1m" data-path="src/pages/HomePage.tsx">
            <div className="flex items-center space-x-3" data-id="7sexz5lk2" data-path="src/pages/HomePage.tsx">
              <div className="p-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg" data-id="s7y3jm4qm" data-path="src/pages/HomePage.tsx">
                <Type className="h-6 w-6 text-white" data-id="enw0y6qpr" data-path="src/pages/HomePage.tsx" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent" data-id="3k2uyn9n8" data-path="src/pages/HomePage.tsx">
                Braille World
              </h1>
            </div>
            <Button
              variant="outline"
              onClick={() => navigate('/about')}
              className="border-gray-300 hover:bg-gray-50" data-id="8hl6cld4e" data-path="src/pages/HomePage.tsx">
              About Us
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4" data-id="y1i2vamcc" data-path="src/pages/HomePage.tsx">
        <div className="max-w-7xl mx-auto text-center" data-id="y34bk9wux" data-path="src/pages/HomePage.tsx">
          <h1 className="text-5xl md:text-7xl font-bold mb-6" data-id="vjdbs0b09" data-path="src/pages/HomePage.tsx">
            <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent" data-id="weby91tru" data-path="src/pages/HomePage.tsx">
              Welcome to
            </span>
            <br data-id="gvjzz9qkc" data-path="src/pages/HomePage.tsx" />
            <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent" data-id="fxlz1s2i8" data-path="src/pages/HomePage.tsx">  
              Braille World
            </span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed" data-id="l2gnzlzs3" data-path="src/pages/HomePage.tsx">
            Empowering communication through advanced Braille technology. Convert text to Braille, 
            extract text from images, and bridge the gap between visual and tactile reading.
          </p>
          <Button
            size="lg"
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 text-lg font-semibold rounded-full transform transition-transform hover:scale-105"
            onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })} data-id="o6y052us5" data-path="src/pages/HomePage.tsx">
            Explore Services
            <ArrowRight className="ml-2 h-5 w-5" data-id="clpq2z5vr" data-path="src/pages/HomePage.tsx" />
          </Button>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-4 bg-white/50" data-id="p2gkt3i38" data-path="src/pages/HomePage.tsx">
        <div className="max-w-7xl mx-auto" data-id="srwdu1hm3" data-path="src/pages/HomePage.tsx">
          <div className="text-center mb-16" data-id="lpa1e9a2i" data-path="src/pages/HomePage.tsx">
            <h2 className="text-4xl font-bold text-gray-800 mb-4" data-id="27hq9l6qc" data-path="src/pages/HomePage.tsx">Our Services</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto" data-id="1dn12y0vm" data-path="src/pages/HomePage.tsx">
              Comprehensive Braille conversion tools designed to make text accessible for everyone
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" data-id="5pkwqmzik" data-path="src/pages/HomePage.tsx">
            {services.map((service, index) =>
            <ServiceCard
              key={index}
              title={service.title}
              description={service.description}
              icon={service.icon}
              gradient={service.gradient}
              customButton={service.customButton}
              onTryIt={service.isExternal ? service.onTryIt : () => navigate(service.path)} data-id="vtrbc98rl" data-path="src/pages/HomePage.tsx" />
            )}
          </div>
        </div>
      </section>

      {/* Key Features Section */}
      <section className="py-20 px-4" data-id="zklzci1tz" data-path="src/pages/HomePage.tsx">
        <div className="max-w-7xl mx-auto" data-id="g9l2ngydz" data-path="src/pages/HomePage.tsx">
          <div className="text-center mb-16" data-id="t54667wx1" data-path="src/pages/HomePage.tsx">
            <h2 className="text-4xl font-bold text-gray-800 mb-4" data-id="1jfeyoo7c" data-path="src/pages/HomePage.tsx">Key Features</h2>
            <p className="text-xl text-gray-600" data-id="c0ifj0cs5" data-path="src/pages/HomePage.tsx">
              Built with modern technology and accessibility in mind
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8" data-id="fvaeb0lef" data-path="src/pages/HomePage.tsx">
            {features.map((feature, index) =>
            <div key={index} className="text-center group" data-id="246as3k4s" data-path="src/pages/HomePage.tsx">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-4 group-hover:scale-110 transition-transform" data-id="y7ifg1pyv" data-path="src/pages/HomePage.tsx">
                  <feature.icon className="h-8 w-8 text-white" data-id="pbj8o7971" data-path="src/pages/HomePage.tsx" />
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2" data-id="onx9vvn7j" data-path="src/pages/HomePage.tsx">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed" data-id="rgdhpd0ax" data-path="src/pages/HomePage.tsx">{feature.description}</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12" data-id="313ar9qtr" data-path="src/pages/HomePage.tsx">
        <div className="max-w-7xl mx-auto px-4 text-center" data-id="e4ng1se5x" data-path="src/pages/HomePage.tsx">
          <div className="flex items-center justify-center space-x-3 mb-4" data-id="d8fdfzwxv" data-path="src/pages/HomePage.tsx">
            <div className="p-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg" data-id="5u6surnqi" data-path="src/pages/HomePage.tsx">
              <Type className="h-6 w-6 text-white" data-id="m5s8q6c9f" data-path="src/pages/HomePage.tsx" />
            </div>
            <h3 className="text-2xl font-bold" data-id="c1k6ivbf4" data-path="src/pages/HomePage.tsx">Braille World</h3>
          </div>
          <p className="text-gray-400 mb-4" data-id="dr3l8ff8c" data-path="src/pages/HomePage.tsx">
            Making the world more accessible, one conversion at a time.
          </p>
          <p className="text-sm text-gray-500" data-id="5ot7eexc6" data-path="src/pages/HomePage.tsx">
            © 2024 Braille World. Built with ❤️ for accessibility.
          </p>
        </div>
      </footer>
    </div>);

};

export default HomePage;