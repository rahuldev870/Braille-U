import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, Image as ImageIcon, Volume2, Download, Copy, ArrowLeft, Home, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useTextToSpeech } from '@/hooks/useTextToSpeech';
import { convertTextToBraille, getBrailleWithMapping } from '@/lib/brailleConverter';
import { useToast } from '@/hooks/use-toast';
import Tesseract from 'tesseract.js';

const ImageToBraillePage: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [extractedText, setExtractedText] = useState('');
  const [brailleOutput, setBrailleOutput] = useState('');
  const [characterMapping, setCharacterMapping] = useState<Array<{original: string;braille: string;}>>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('eng');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { speak, isSpeaking } = useTextToSpeech();

  // Map OCR language codes to speech synthesis language codes
  const getLanguageCode = (ocrLang: string): string => {
    switch (ocrLang) {
      case 'hin':
        return 'hi-IN';
      case 'eng+hin':
        return 'hi-IN'; // Default to Hindi for mixed content
      case 'eng':
      default:
        return 'en-US';
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        setSelectedImage(file);
        const reader = new FileReader();
        reader.onload = (e) => {
          setImagePreview(e.target?.result as string);
        };
        reader.readAsDataURL(file);

        // Clear previous results
        setExtractedText('');
        setBrailleOutput('');
        setCharacterMapping([]);
      } else {
        toast({
          title: "Invalid File",
          description: "Please select a valid image file",
          variant: "destructive"
        });
      }
    }
  };

  const processImage = async () => {
    if (!selectedImage) return;

    setIsProcessing(true);

    try {
      // Configure Tesseract for the selected language
      const { data: { text } } = await Tesseract.recognize(
        selectedImage,
        selectedLanguage,
        {
          logger: (m) => {
            if (m.status === 'recognizing text') {
              console.log(`OCR Progress: ${Math.round(m.progress * 100)}%`);
            }
          }
        }
      );

      console.log('Extracted text:', text);
      setExtractedText(text);

      // Convert to Braille with enhanced Hindi support including matras
      const { braille, mapping } = getBrailleWithMapping(text);
      setBrailleOutput(braille);
      setCharacterMapping(mapping);

      toast({
        title: "Success",
        description: `Text extracted and converted to Braille! ${mapping.length} characters processed.`
      });
    } catch (error) {
      console.error('OCR Error:', error);
      toast({
        title: "Processing Error",
        description: "Failed to extract text from image. Please try with a clearer image.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCopy = async (text: string, type: string) => {
    if (!text) return;

    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Success",
        description: `${type} copied to clipboard!`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive"
      });
    }
  };

  const handleDownload = (text: string, filename: string) => {
    if (!text) return;

    const element = document.createElement('a');
    const file = new Blob([text], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = filename;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);

    toast({
      title: "Success",
      description: `${filename} downloaded successfully!`
    });
  };

  const handleSpeak = (text: string) => {
    if (text.trim()) {
      // Get the appropriate language code for speech synthesis
      const languageCode = getLanguageCode(selectedLanguage);
      console.log(`Speaking text in ${languageCode}:`, text);

      // Pass the correct language to the speech function
      speak(text, languageCode);

      toast({
        title: "Reading Aloud",
        description: `Reading text in ${selectedLanguage === 'hin' ? 'Hindi' : selectedLanguage === 'eng+hin' ? 'Hindi/English' : 'English'}`
      });
    } else {
      toast({
        title: "No Text",
        description: "No text available to read aloud",
        variant: "destructive"
      });
    }
  };

  const clearAll = () => {
    setSelectedImage(null);
    setImagePreview('');
    setExtractedText('');
    setBrailleOutput('');
    setCharacterMapping([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 py-8 px-4" data-id="7dzqmyrjm" data-path="src/pages/ImageToBraillePage.tsx">
      <div className="max-w-6xl mx-auto" data-id="cha69wo3h" data-path="src/pages/ImageToBraillePage.tsx">
        {/* Header with Back Button */}
        <div className="flex items-center justify-between mb-8" data-id="zp3k1brz1" data-path="src/pages/ImageToBraillePage.tsx">
          <div className="flex items-center gap-4" data-id="c7afquqm9" data-path="src/pages/ImageToBraillePage.tsx">
            <Link to="/" data-id="1gu3ratrh" data-path="src/pages/ImageToBraillePage.tsx">
              <Button variant="outline" size="sm" className="flex items-center gap-2" data-id="se1tvl1nb" data-path="src/pages/ImageToBraillePage.tsx">
                <ArrowLeft className="h-4 w-4" data-id="9ey2cjp93" data-path="src/pages/ImageToBraillePage.tsx" />
                Back
              </Button>
            </Link>
            <Link to="/" data-id="rj00mp1tw" data-path="src/pages/ImageToBraillePage.tsx">
              <Button variant="ghost" size="sm" className="flex items-center gap-2" data-id="jjkln2etd" data-path="src/pages/ImageToBraillePage.tsx">
                <Home className="h-4 w-4" data-id="ols9rb56a" data-path="src/pages/ImageToBraillePage.tsx" />
                Home
              </Button>
            </Link>
          </div>
          <Button
            onClick={clearAll}
            variant="outline"
            size="sm"
            className="flex items-center gap-2" data-id="8rdvmmjz8" data-path="src/pages/ImageToBraillePage.tsx">

            <RefreshCw className="h-4 w-4" data-id="o53kfl64g" data-path="src/pages/ImageToBraillePage.tsx" />
            Clear All
          </Button>
        </div>

        <div className="text-center mb-8" data-id="ksh62oydq" data-path="src/pages/ImageToBraillePage.tsx">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-4" data-id="qmvcb8uzw" data-path="src/pages/ImageToBraillePage.tsx">
            Image to Braille Converter
          </h1>
          <p className="text-gray-600 text-lg" data-id="yrsr5reg0" data-path="src/pages/ImageToBraillePage.tsx">
            Extract text from images and convert to Braille with enhanced Hindi support including matras
          </p>
        </div>

        {/* Upload Section */}
        <Card className="mb-8 shadow-lg border-0 bg-white/80 backdrop-blur-sm" data-id="r18iiju8h" data-path="src/pages/ImageToBraillePage.tsx">
          <CardHeader data-id="6g1teymia" data-path="src/pages/ImageToBraillePage.tsx">
            <CardTitle data-id="wl0cfgnon" data-path="src/pages/ImageToBraillePage.tsx">Upload Image</CardTitle>
            <CardDescription data-id="8g5gdnsqg" data-path="src/pages/ImageToBraillePage.tsx">
              Select an image containing text in English or Hindi. Hindi matras will be properly recognized and converted.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4" data-id="g8ih4qdu5" data-path="src/pages/ImageToBraillePage.tsx">
            <div className="flex gap-4 items-end" data-id="izqi6yid3" data-path="src/pages/ImageToBraillePage.tsx">
              <div className="flex-1" data-id="do6djngjz" data-path="src/pages/ImageToBraillePage.tsx">
                <Select value={selectedLanguage} onValueChange={setSelectedLanguage} data-id="dvhymvh8m" data-path="src/pages/ImageToBraillePage.tsx">
                  <SelectTrigger data-id="s0zwmtlm2" data-path="src/pages/ImageToBraillePage.tsx">
                    <SelectValue placeholder="Select language" data-id="kgxf12tc1" data-path="src/pages/ImageToBraillePage.tsx" />
                  </SelectTrigger>
                  <SelectContent data-id="sdif3hk0t" data-path="src/pages/ImageToBraillePage.tsx">
                    <SelectItem value="eng" data-id="y0f2hzum9" data-path="src/pages/ImageToBraillePage.tsx">English</SelectItem>
                    <SelectItem value="hin" data-id="79yfinmpt" data-path="src/pages/ImageToBraillePage.tsx">Hindi</SelectItem>
                    <SelectItem value="eng+hin" data-id="jbwe2paxj" data-path="src/pages/ImageToBraillePage.tsx">English + Hindi</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden" data-id="wytb29h11" data-path="src/pages/ImageToBraillePage.tsx" />

              <Button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2" data-id="h4hrytv3a" data-path="src/pages/ImageToBraillePage.tsx">

                <Upload className="h-4 w-4" data-id="9u9t0mm9y" data-path="src/pages/ImageToBraillePage.tsx" />
                Choose Image
              </Button>
              <Button
                onClick={processImage}
                disabled={!selectedImage || isProcessing}
                className="flex items-center gap-2" data-id="e27v112fn" data-path="src/pages/ImageToBraillePage.tsx">

                <ImageIcon className="h-4 w-4" data-id="kwk7zakyv" data-path="src/pages/ImageToBraillePage.tsx" />
                {isProcessing ? 'Processing...' : 'Extract Text'}
              </Button>
            </div>

            {imagePreview &&
            <div className="mt-4" data-id="vqylpslbp" data-path="src/pages/ImageToBraillePage.tsx">
                <img
                src={imagePreview}
                alt="Selected"
                className="max-w-full max-h-64 mx-auto rounded-lg shadow-md" data-id="ciqnht3bf" data-path="src/pages/ImageToBraillePage.tsx" />

              </div>
            }
          </CardContent>
        </Card>

        {isProcessing &&
        <Card className="mb-8 shadow-lg border-0 bg-white/80 backdrop-blur-sm" data-id="07niqcijl" data-path="src/pages/ImageToBraillePage.tsx">
            <CardContent className="pt-6" data-id="c9umof0gx" data-path="src/pages/ImageToBraillePage.tsx">
              <div className="text-center" data-id="iv4m9ij0j" data-path="src/pages/ImageToBraillePage.tsx">
                <div className="inline-flex items-center gap-2 text-blue-600" data-id="p9c7omxho" data-path="src/pages/ImageToBraillePage.tsx">
                  <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" data-id="c4ckp9pbh" data-path="src/pages/ImageToBraillePage.tsx"></div>
                  Processing image and extracting text...
                </div>
              </div>
            </CardContent>
          </Card>
        }

        <div className="grid lg:grid-cols-2 gap-8" data-id="lzrm8rthi" data-path="src/pages/ImageToBraillePage.tsx">
          {/* Extracted Text */}
          {extractedText &&
          <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm" data-id="wmndufoyt" data-path="src/pages/ImageToBraillePage.tsx">
              <CardHeader data-id="7ke4m55yn" data-path="src/pages/ImageToBraillePage.tsx">
                <CardTitle className="flex items-center gap-2" data-id="npk9rops2" data-path="src/pages/ImageToBraillePage.tsx">
                  Extracted Text
                  <div className="flex gap-2 ml-auto" data-id="xin5vhsfj" data-path="src/pages/ImageToBraillePage.tsx">
                    <Button
                    onClick={() => handleSpeak(extractedText)}
                    variant="outline"
                    size="sm"
                    disabled={isSpeaking}
                    title="Read Aloud" data-id="lm67unv07" data-path="src/pages/ImageToBraillePage.tsx">

                      <Volume2 className="h-4 w-4" data-id="l0u39k19w" data-path="src/pages/ImageToBraillePage.tsx" />
                    </Button>
                    <Button
                    onClick={() => handleCopy(extractedText, 'Text')}
                    variant="outline"
                    size="sm"
                    title="Copy Text" data-id="3y3hbin1w" data-path="src/pages/ImageToBraillePage.tsx">

                      <Copy className="h-4 w-4" data-id="m3zpxuooj" data-path="src/pages/ImageToBraillePage.tsx" />
                    </Button>
                    <Button
                    onClick={() => handleDownload(extractedText, 'extracted-text.txt')}
                    variant="outline"
                    size="sm"
                    title="Download Text" data-id="i6clvrvm8" data-path="src/pages/ImageToBraillePage.tsx">

                      <Download className="h-4 w-4" data-id="o2ryqh62f" data-path="src/pages/ImageToBraillePage.tsx" />
                    </Button>
                  </div>
                </CardTitle>
                <CardDescription data-id="9dad3sej9" data-path="src/pages/ImageToBraillePage.tsx">
                  Text extracted from the image using OCR
                </CardDescription>
              </CardHeader>
              <CardContent data-id="u9tjo5pmv" data-path="src/pages/ImageToBraillePage.tsx">
                <div className="min-h-[200px] p-4 border rounded-lg bg-gray-50" data-id="rjo3theyx" data-path="src/pages/ImageToBraillePage.tsx">
                  <div className="text-lg leading-relaxed whitespace-pre-wrap" data-id="ldek5v6qf" data-path="src/pages/ImageToBraillePage.tsx">
                    {extractedText}
                  </div>
                </div>
              </CardContent>
            </Card>
          }

          {/* Braille Output */}
          {brailleOutput &&
          <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm" data-id="xnwkf6sag" data-path="src/pages/ImageToBraillePage.tsx">
              <CardHeader data-id="pzvzkccm1" data-path="src/pages/ImageToBraillePage.tsx">
                <CardTitle className="flex items-center gap-2" data-id="7t5jn98z6" data-path="src/pages/ImageToBraillePage.tsx">
                  Braille Output
                  <div className="flex gap-2 ml-auto" data-id="ve1sw0a31" data-path="src/pages/ImageToBraillePage.tsx">
                    <Button
                    onClick={() => handleCopy(brailleOutput, 'Braille')}
                    variant="outline"
                    size="sm"
                    title="Copy Braille" data-id="zizjjpvj4" data-path="src/pages/ImageToBraillePage.tsx">

                      <Copy className="h-4 w-4" data-id="nqv2opu2l" data-path="src/pages/ImageToBraillePage.tsx" />
                    </Button>
                    <Button
                    onClick={() => handleDownload(brailleOutput, 'braille-output.txt')}
                    variant="outline"
                    size="sm"
                    title="Download Braille" data-id="picqrcw1e" data-path="src/pages/ImageToBraillePage.tsx">

                      <Download className="h-4 w-4" data-id="gf7q2sg0f" data-path="src/pages/ImageToBraillePage.tsx" />
                    </Button>
                  </div>
                </CardTitle>
                <CardDescription data-id="r4i3kzcou" data-path="src/pages/ImageToBraillePage.tsx">
                  Braille representation with proper Hindi matras support
                </CardDescription>
              </CardHeader>
              <CardContent data-id="s5oaewkmf" data-path="src/pages/ImageToBraillePage.tsx">
                <div className="min-h-[200px] p-4 border rounded-lg bg-gray-50" data-id="79eq7o26z" data-path="src/pages/ImageToBraillePage.tsx">
                  <div className="text-4xl font-mono leading-relaxed break-all" data-id="mpi707u9v" data-path="src/pages/ImageToBraillePage.tsx">
                    {brailleOutput}
                  </div>
                </div>
              </CardContent>
            </Card>
          }
        </div>

        {/* Character Mapping */}
        {characterMapping.length > 0 &&
        <Card className="mt-8 shadow-lg border-0 bg-white/80 backdrop-blur-sm" data-id="qccxocd4s" data-path="src/pages/ImageToBraillePage.tsx">
            <CardHeader data-id="zngbn34tj" data-path="src/pages/ImageToBraillePage.tsx">
              <CardTitle data-id="pjppyo1ec" data-path="src/pages/ImageToBraillePage.tsx">Character Mapping</CardTitle>
              <CardDescription data-id="u098d4aes" data-path="src/pages/ImageToBraillePage.tsx">
                See how each character (including Hindi matras) maps to Braille
              </CardDescription>
            </CardHeader>
            <CardContent data-id="7o2jlvnoz" data-path="src/pages/ImageToBraillePage.tsx">
              <div className="grid gap-2 max-h-60 overflow-y-auto" data-id="jmljjbeje" data-path="src/pages/ImageToBraillePage.tsx">
                {characterMapping.map((item, index) =>
              <div
                key={index}
                className="flex items-center justify-between p-2 bg-gray-50 rounded-lg" data-id="uaeay4iie" data-path="src/pages/ImageToBraillePage.tsx">

                    <span className="text-lg font-medium" data-id="p4pkts1ql" data-path="src/pages/ImageToBraillePage.tsx">{item.original}</span>
                    <span className="text-2xl font-mono" data-id="afmbowvax" data-path="src/pages/ImageToBraillePage.tsx">{item.braille}</span>
                  </div>
              )}
              </div>
            </CardContent>
          </Card>
        }

        {/* Feature Information */}
        <Card className="mt-8 shadow-lg border-0 bg-gradient-to-r from-green-50 to-blue-50" data-id="h1fhrpswk" data-path="src/pages/ImageToBraillePage.tsx">
          <CardContent className="pt-6" data-id="0qw8yfyx6" data-path="src/pages/ImageToBraillePage.tsx">
            <div className="grid md:grid-cols-4 gap-6 text-center" data-id="it9q6hhq5" data-path="src/pages/ImageToBraillePage.tsx">
              <div data-id="6tg6io6n5" data-path="src/pages/ImageToBraillePage.tsx">
                <div className="text-3xl mb-2" data-id="pb9kf9z65" data-path="src/pages/ImageToBraillePage.tsx">📸</div>
                <h3 className="font-semibold mb-1" data-id="ud70f35pc" data-path="src/pages/ImageToBraillePage.tsx">OCR Technology</h3>
                <p className="text-sm text-gray-600" data-id="4vkrhvmhr" data-path="src/pages/ImageToBraillePage.tsx">
                  Advanced text recognition from images
                </p>
              </div>
              <div data-id="58cyakm6m" data-path="src/pages/ImageToBraillePage.tsx">
                <div className="text-3xl mb-2" data-id="jc2m6icg8" data-path="src/pages/ImageToBraillePage.tsx">🌐</div>
                <h3 className="font-semibold mb-1" data-id="4kkvvqdza" data-path="src/pages/ImageToBraillePage.tsx">Multi-language</h3>
                <p className="text-sm text-gray-600" data-id="6j2qx92jn" data-path="src/pages/ImageToBraillePage.tsx">
                  Support for English and Hindi text
                </p>
              </div>
              <div data-id="ya177wbou" data-path="src/pages/ImageToBraillePage.tsx">
                <div className="text-3xl mb-2" data-id="4bfhy6q90" data-path="src/pages/ImageToBraillePage.tsx">🇮🇳</div>
                <h3 className="font-semibold mb-1" data-id="u02umjo77" data-path="src/pages/ImageToBraillePage.tsx">Hindi Matras</h3>
                <p className="text-sm text-gray-600" data-id="wxpu0uj4i" data-path="src/pages/ImageToBraillePage.tsx">
                  Proper recognition of Hindi vowel signs
                </p>
              </div>
              <div data-id="al9mllti2" data-path="src/pages/ImageToBraillePage.tsx">
                <div className="text-3xl mb-2" data-id="u68g9uz0c" data-path="src/pages/ImageToBraillePage.tsx">🔊</div>
                <h3 className="font-semibold mb-1" data-id="c49f97797" data-path="src/pages/ImageToBraillePage.tsx">Audio Support</h3>
                <p className="text-sm text-gray-600" data-id="s0y39gd28" data-path="src/pages/ImageToBraillePage.tsx">
                  Listen to the extracted text
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>);

};

export default ImageToBraillePage;