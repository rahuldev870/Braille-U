import React, { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Home, ExternalLink, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';

const ExternalBrailleToolPage: React.FC = () => {
  const { toast } = useToast();

  useEffect(() => {
    // Open the external tool automatically
    const openExternalTool = () => {
      window.open('https://braille-speech-converter.onrender.com', '_blank');

      toast({
        title: "External Tool Opened",
        description: "The Braille to Speech Converter has opened in a new tab. Return here when finished."
      });
    };

    // Small delay to ensure page loads before opening
    const timer = setTimeout(openExternalTool, 1000);

    return () => clearTimeout(timer);
  }, [toast]);

  const handleOpenAgain = () => {
    window.open('https://braille-speech-converter.onrender.com', '_blank');
    toast({
      title: "Tool Reopened",
      description: "The external tool has been reopened in a new tab."
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 py-8 px-4" data-id="a6qux7pr0" data-path="src/pages/ExternalBrailleToolPage.tsx">
      <div className="max-w-4xl mx-auto" data-id="wkqajpna6" data-path="src/pages/ExternalBrailleToolPage.tsx">
        {/* Header with Back Button */}
        <div className="flex items-center justify-between mb-8" data-id="jvlk1dc8g" data-path="src/pages/ExternalBrailleToolPage.tsx">
          <div className="flex items-center gap-4" data-id="p76t18av3" data-path="src/pages/ExternalBrailleToolPage.tsx">
            <Link to="/" data-id="h11qrkvnp" data-path="src/pages/ExternalBrailleToolPage.tsx">
              <Button variant="outline" size="sm" className="flex items-center gap-2" data-id="ylbvdtcz0" data-path="src/pages/ExternalBrailleToolPage.tsx">
                <ArrowLeft className="h-4 w-4" data-id="fv40087sa" data-path="src/pages/ExternalBrailleToolPage.tsx" />
                Back to Home
              </Button>
            </Link>
            <Link to="/" data-id="w3a26i1nz" data-path="src/pages/ExternalBrailleToolPage.tsx">
              <Button variant="ghost" size="sm" className="flex items-center gap-2" data-id="bv8gnh5f5" data-path="src/pages/ExternalBrailleToolPage.tsx">
                <Home className="h-4 w-4" data-id="b2qhn4itg" data-path="src/pages/ExternalBrailleToolPage.tsx" />
                Home
              </Button>
            </Link>
          </div>
          <Button
            onClick={handleOpenAgain}
            variant="outline"
            size="sm"
            className="flex items-center gap-2" data-id="irr53daxg" data-path="src/pages/ExternalBrailleToolPage.tsx">
            <RefreshCw className="h-4 w-4" data-id="qmmuk14pw" data-path="src/pages/ExternalBrailleToolPage.tsx" />
            Reopen Tool
          </Button>
        </div>

        <div className="text-center mb-8" data-id="q2e0dd5id" data-path="src/pages/ExternalBrailleToolPage.tsx">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-4" data-id="mn8qsj8ob" data-path="src/pages/ExternalBrailleToolPage.tsx">
            Braille to Speech Converter
          </h1>
          <p className="text-gray-600 text-lg" data-id="q83ijh5i3" data-path="src/pages/ExternalBrailleToolPage.tsx">
            External tool for converting Braille images and patterns to speech
          </p>
        </div>

        {/* Main Service Card */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm mb-8" data-id="urnq8xner" data-path="src/pages/ExternalBrailleToolPage.tsx">
          <CardHeader className="text-center" data-id="3mxjojfnx" data-path="src/pages/ExternalBrailleToolPage.tsx">
            <CardTitle className="text-2xl" data-id="8xtlew87t" data-path="src/pages/ExternalBrailleToolPage.tsx">
              External Braille Tool Hub
            </CardTitle>
            <CardDescription className="text-lg" data-id="2kj93nf0x" data-path="src/pages/ExternalBrailleToolPage.tsx">
              Access the specialized Braille to Speech Converter tool
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6" data-id="aiku9d16n" data-path="src/pages/ExternalBrailleToolPage.tsx">
            <div className="text-center" data-id="aibof6lp9" data-path="src/pages/ExternalBrailleToolPage.tsx">
              <div className="text-6xl mb-4" data-id="4imm561rd" data-path="src/pages/ExternalBrailleToolPage.tsx">🎯</div>
              <p className="text-gray-600 mb-6" data-id="9btipjnaw" data-path="src/pages/ExternalBrailleToolPage.tsx">
                The external Braille to Speech Converter tool should have opened in a new tab. 
                If it didn't open automatically, click the button below to access it.
              </p>
            </div>

            <div className="bg-gradient-to-r from-purple-100 to-pink-100 rounded-lg p-6" data-id="y9kvvfjfl" data-path="src/pages/ExternalBrailleToolPage.tsx">
              <h3 className="font-semibold text-lg mb-3" data-id="2b0jgzafp" data-path="src/pages/ExternalBrailleToolPage.tsx">External Tool Features:</h3>
              <div className="grid md:grid-cols-2 gap-4" data-id="fuy2heglf" data-path="src/pages/ExternalBrailleToolPage.tsx">
                <div className="space-y-2" data-id="nyevz0ybn" data-path="src/pages/ExternalBrailleToolPage.tsx">
                  <div className="flex items-center gap-2" data-id="bqq47t66z" data-path="src/pages/ExternalBrailleToolPage.tsx">
                    <span className="text-green-600" data-id="sjrby05a9" data-path="src/pages/ExternalBrailleToolPage.tsx">✓</span>
                    <span data-id="vnvxi08pr" data-path="src/pages/ExternalBrailleToolPage.tsx">Braille image recognition</span>
                  </div>
                  <div className="flex items-center gap-2" data-id="hb6bdk6bu" data-path="src/pages/ExternalBrailleToolPage.tsx">
                    <span className="text-green-600" data-id="eitjtiu8f" data-path="src/pages/ExternalBrailleToolPage.tsx">✓</span>
                    <span data-id="otsdlzhvq" data-path="src/pages/ExternalBrailleToolPage.tsx">Text to speech conversion</span>
                  </div>
                  <div className="flex items-center gap-2" data-id="mnmhpqatk" data-path="src/pages/ExternalBrailleToolPage.tsx">
                    <span className="text-green-600" data-id="1typ1kb6d" data-path="src/pages/ExternalBrailleToolPage.tsx">✓</span>
                    <span data-id="l5w14dh1z" data-path="src/pages/ExternalBrailleToolPage.tsx">Multiple file format support</span>
                  </div>
                </div>
                <div className="space-y-2" data-id="pf861tb9b" data-path="src/pages/ExternalBrailleToolPage.tsx">
                  <div className="flex items-center gap-2" data-id="1gi46dxdn" data-path="src/pages/ExternalBrailleToolPage.tsx">
                    <span className="text-green-600" data-id="0nilpxvhe" data-path="src/pages/ExternalBrailleToolPage.tsx">✓</span>
                    <span data-id="isd6deiz8" data-path="src/pages/ExternalBrailleToolPage.tsx">Real-time processing</span>
                  </div>
                  <div className="flex items-center gap-2" data-id="aed3dhxpa" data-path="src/pages/ExternalBrailleToolPage.tsx">
                    <span className="text-green-600" data-id="66u1aqzsc" data-path="src/pages/ExternalBrailleToolPage.tsx">✓</span>
                    <span data-id="8j6dh941t" data-path="src/pages/ExternalBrailleToolPage.tsx">Audio output options</span>
                  </div>
                  <div className="flex items-center gap-2" data-id="t2ncw17ze" data-path="src/pages/ExternalBrailleToolPage.tsx">
                    <span className="text-green-600" data-id="eoojb56ia" data-path="src/pages/ExternalBrailleToolPage.tsx">✓</span>
                    <span data-id="u6wefut4i" data-path="src/pages/ExternalBrailleToolPage.tsx">Easy-to-use interface</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-center space-y-4" data-id="1rqiaynn9" data-path="src/pages/ExternalBrailleToolPage.tsx">
              <Button
                onClick={handleOpenAgain}
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 text-lg" data-id="dsnbphz52" data-path="src/pages/ExternalBrailleToolPage.tsx">
                <ExternalLink className="mr-2 h-5 w-5" data-id="ib3ler97o" data-path="src/pages/ExternalBrailleToolPage.tsx" />
                Open Braille to Speech Converter
              </Button>
              <p className="text-sm text-gray-500" data-id="6d9a2mobm" data-path="src/pages/ExternalBrailleToolPage.tsx">
                Opens in a new tab - Use this page to navigate back to our services
              </p>
            </div>

            <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded" data-id="cu7rmhlgn" data-path="src/pages/ExternalBrailleToolPage.tsx">
              <div className="flex items-start gap-3" data-id="zyc1o8ipe" data-path="src/pages/ExternalBrailleToolPage.tsx">
                <span className="text-blue-600 text-xl" data-id="obgjhndp6" data-path="src/pages/ExternalBrailleToolPage.tsx">💡</span>
                <div data-id="aru1j7kp1" data-path="src/pages/ExternalBrailleToolPage.tsx">
                  <h4 className="font-semibold text-blue-800" data-id="ibmb27q8o" data-path="src/pages/ExternalBrailleToolPage.tsx">Navigation Tip:</h4>
                  <p className="text-sm text-blue-700 mt-1" data-id="1h5i1r1eb" data-path="src/pages/ExternalBrailleToolPage.tsx">
                    Keep this tab open to easily return to our other Braille conversion services when you're done with the external tool.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Return Navigation */}
        <Card className="shadow-lg border-0 bg-gradient-to-r from-purple-50 to-pink-50" data-id="tic2bd3ij" data-path="src/pages/ExternalBrailleToolPage.tsx">
          <CardContent className="pt-6" data-id="mrr20ekm8" data-path="src/pages/ExternalBrailleToolPage.tsx">
            <div className="text-center" data-id="wpablcar5" data-path="src/pages/ExternalBrailleToolPage.tsx">
              <h3 className="font-semibold text-lg mb-4" data-id="djyt3utpg" data-path="src/pages/ExternalBrailleToolPage.tsx">Ready to explore our other services?</h3>
              <div className="flex flex-wrap justify-center gap-4" data-id="sxwzupibe" data-path="src/pages/ExternalBrailleToolPage.tsx">
                <Link to="/text-to-braille" data-id="etclkef0x" data-path="src/pages/ExternalBrailleToolPage.tsx">
                  <Button variant="outline" className="flex items-center gap-2" data-id="a5k2qb7zs" data-path="src/pages/ExternalBrailleToolPage.tsx">
                    Text to Braille
                  </Button>
                </Link>
                <Link to="/image-to-braille" data-id="v6iytrp6d" data-path="src/pages/ExternalBrailleToolPage.tsx">
                  <Button variant="outline" className="flex items-center gap-2" data-id="4ho812s5b" data-path="src/pages/ExternalBrailleToolPage.tsx">
                    Image to Braille
                  </Button>
                </Link>
                <Link to="/braille-to-text" data-id="1bn272i4p" data-path="src/pages/ExternalBrailleToolPage.tsx">
                  <Button variant="outline" className="flex items-center gap-2" data-id="46blqlz5p" data-path="src/pages/ExternalBrailleToolPage.tsx">
                    Braille Image to Text
                  </Button>
                </Link>
                <Link to="/about" data-id="j75w7rq63" data-path="src/pages/ExternalBrailleToolPage.tsx">
                  <Button variant="outline" className="flex items-center gap-2" data-id="154dtxtxm" data-path="src/pages/ExternalBrailleToolPage.tsx">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Status Indicator */}
        <div className="mt-8 text-center" data-id="25039onb9" data-path="src/pages/ExternalBrailleToolPage.tsx">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-100 text-green-800 rounded-full" data-id="vs4qdzhsg" data-path="src/pages/ExternalBrailleToolPage.tsx">
            <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse" data-id="kfb4pw4wa" data-path="src/pages/ExternalBrailleToolPage.tsx"></div>
            External tool ready - Return here anytime
          </div>
        </div>
      </div>
    </div>);

};

export default ExternalBrailleToolPage;