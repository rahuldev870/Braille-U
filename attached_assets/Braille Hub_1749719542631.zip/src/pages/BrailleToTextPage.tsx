import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ExternalLink, ArrowLeft, Home, Info } from 'lucide-react';
import { Link } from 'react-router-dom';

const BrailleToTextPage: React.FC = () => {
  const [showInfo, setShowInfo] = useState(false);

  const handleExternalLink = () => {
    window.open('https://www.pharmabraille.com/pharmaceutical-braille/braille-translator/', '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 py-8 px-4" data-id="cfy64xqur" data-path="src/pages/BrailleToTextPage.tsx">
      <div className="max-w-4xl mx-auto" data-id="kd13i54mk" data-path="src/pages/BrailleToTextPage.tsx">
        {/* Header with Back Button */}
        <div className="flex items-center justify-between mb-8" data-id="aifb21kbf" data-path="src/pages/BrailleToTextPage.tsx">
          <div className="flex items-center gap-4" data-id="v5a90pd28" data-path="src/pages/BrailleToTextPage.tsx">
            <Link to="/" data-id="mp0nwgwav" data-path="src/pages/BrailleToTextPage.tsx">
              <Button variant="outline" size="sm" className="flex items-center gap-2" data-id="0dhcltary" data-path="src/pages/BrailleToTextPage.tsx">
                <ArrowLeft className="h-4 w-4" data-id="pjnxbfa0x" data-path="src/pages/BrailleToTextPage.tsx" />
                Back
              </Button>
            </Link>
            <Link to="/" data-id="9ae76o4oj" data-path="src/pages/BrailleToTextPage.tsx">
              <Button variant="ghost" size="sm" className="flex items-center gap-2" data-id="dnadg41nz" data-path="src/pages/BrailleToTextPage.tsx">
                <Home className="h-4 w-4" data-id="b1vev7yi9" data-path="src/pages/BrailleToTextPage.tsx" />
                Home
              </Button>
            </Link>
          </div>
          <Button
            onClick={() => setShowInfo(!showInfo)}
            variant="outline"
            size="sm"
            className="flex items-center gap-2" data-id="bzslgmrju" data-path="src/pages/BrailleToTextPage.tsx">

            <Info className="h-4 w-4" data-id="49y6mxfrb" data-path="src/pages/BrailleToTextPage.tsx" />
            {showInfo ? 'Hide Info' : 'Show Info'}
          </Button>
        </div>

        <div className="text-center mb-8" data-id="ym2y6ikrc" data-path="src/pages/BrailleToTextPage.tsx">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-4" data-id="dyyi3i0q5" data-path="src/pages/BrailleToTextPage.tsx">
            Braille Image to Text Converter
          </h1>
          <p className="text-gray-600 text-lg" data-id="6qzo4ri9n" data-path="src/pages/BrailleToTextPage.tsx">
            Convert Braille image patterns back to readable text
          </p>
        </div>

        {/* Information Card */}
        {showInfo &&
        <Card className="mb-8 shadow-lg border-0 bg-blue-50/80 backdrop-blur-sm" data-id="dh6zu5eji" data-path="src/pages/BrailleToTextPage.tsx">
            <CardHeader data-id="5d9z6oxfl" data-path="src/pages/BrailleToTextPage.tsx">
              <CardTitle className="flex items-center gap-2" data-id="mcvmakztw" data-path="src/pages/BrailleToTextPage.tsx">
                <Info className="h-5 w-5 text-blue-600" data-id="op1z6atyi" data-path="src/pages/BrailleToTextPage.tsx" />
                About Braille Image to Text Conversion
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4" data-id="y1ysze1v4" data-path="src/pages/BrailleToTextPage.tsx">
              <p className="text-gray-700" data-id="zg5tj0c02" data-path="src/pages/BrailleToTextPage.tsx">
                Converting Braille images back to text requires specialized optical recognition 
                technology that can identify Braille dot patterns and translate them accurately.
              </p>
              <div className="bg-white/60 rounded-lg p-4" data-id="6k8vycoa9" data-path="src/pages/BrailleToTextPage.tsx">
                <h4 className="font-semibold text-gray-800 mb-2" data-id="tmu4842c4" data-path="src/pages/BrailleToTextPage.tsx">Why use an external service?</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700 text-sm" data-id="mbvlq7xwb" data-path="src/pages/BrailleToTextPage.tsx">
                  <li data-id="n3j7uw03g" data-path="src/pages/BrailleToTextPage.tsx">Specialized algorithms for Braille dot pattern recognition</li>
                  <li data-id="bo8u60q57" data-path="src/pages/BrailleToTextPage.tsx">High accuracy requirements for reading assistance</li>
                  <li data-id="92xhfcxwa" data-path="src/pages/BrailleToTextPage.tsx">Complex image processing for various Braille formats</li>
                  <li data-id="tc6lelh2o" data-path="src/pages/BrailleToTextPage.tsx">Continuous updates and improvements to recognition technology</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        }

        {/* Main Service Card */}
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm" data-id="dzx1zcmdb" data-path="src/pages/BrailleToTextPage.tsx">
          <CardHeader className="text-center" data-id="xj12tmdzx" data-path="src/pages/BrailleToTextPage.tsx">
            <CardTitle className="text-2xl" data-id="baai9exxe" data-path="src/pages/BrailleToTextPage.tsx">
              Professional Braille Image Recognition
            </CardTitle>
            <CardDescription className="text-lg" data-id="d2tw04fuw" data-path="src/pages/BrailleToTextPage.tsx">
              Use our recommended external service for accurate Braille image to text conversion
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6" data-id="kan2bjxxf" data-path="src/pages/BrailleToTextPage.tsx">
            <div className="text-center" data-id="pq4g8k7bz" data-path="src/pages/BrailleToTextPage.tsx">
              <div className="text-6xl mb-4" data-id="vpq8f5ovz" data-path="src/pages/BrailleToTextPage.tsx">📖</div>
              <p className="text-gray-600 mb-6" data-id="p242c5be9" data-path="src/pages/BrailleToTextPage.tsx">
                For the most accurate conversion of Braille images to text, we recommend using 
                a specialized external service that provides professional-grade optical 
                Braille recognition technology.
              </p>
            </div>

            <div className="bg-gradient-to-r from-purple-100 to-pink-100 rounded-lg p-6" data-id="hy9ahkqx3" data-path="src/pages/BrailleToTextPage.tsx">
              <h3 className="font-semibold text-lg mb-3" data-id="9wgvrq55s" data-path="src/pages/BrailleToTextPage.tsx">Features of the External Service:</h3>
              <div className="grid md:grid-cols-2 gap-4" data-id="h3rk4rgxy" data-path="src/pages/BrailleToTextPage.tsx">
                <div className="space-y-2" data-id="23vocr3zb" data-path="src/pages/BrailleToTextPage.tsx">
                  <div className="flex items-center gap-2" data-id="r7xqcej2q" data-path="src/pages/BrailleToTextPage.tsx">
                    <span className="text-green-600" data-id="3vsp40xkd" data-path="src/pages/BrailleToTextPage.tsx">✓</span>
                    <span data-id="tct1z1go0" data-path="src/pages/BrailleToTextPage.tsx">High accuracy OCR for Braille</span>
                  </div>
                  <div className="flex items-center gap-2" data-id="7ichklreb" data-path="src/pages/BrailleToTextPage.tsx">
                    <span className="text-green-600" data-id="frlhzmybz" data-path="src/pages/BrailleToTextPage.tsx">✓</span>
                    <span data-id="9ille5nhb" data-path="src/pages/BrailleToTextPage.tsx">Multiple Braille formats supported</span>
                  </div>
                  <div className="flex items-center gap-2" data-id="hfbxg06iq" data-path="src/pages/BrailleToTextPage.tsx">
                    <span className="text-green-600" data-id="8dl21diwc" data-path="src/pages/BrailleToTextPage.tsx">✓</span>
                    <span data-id="iunt693hp" data-path="src/pages/BrailleToTextPage.tsx">Various image formats accepted</span>
                  </div>
                </div>
                <div className="space-y-2" data-id="vwu3ylwbp" data-path="src/pages/BrailleToTextPage.tsx">
                  <div className="flex items-center gap-2" data-id="3riqe4p4x" data-path="src/pages/BrailleToTextPage.tsx">
                    <span className="text-green-600" data-id="h1j84ctbo" data-path="src/pages/BrailleToTextPage.tsx">✓</span>
                    <span data-id="arcp1hq5j" data-path="src/pages/BrailleToTextPage.tsx">Fast processing times</span>
                  </div>
                  <div className="flex items-center gap-2" data-id="eayolkjx4" data-path="src/pages/BrailleToTextPage.tsx">
                    <span className="text-green-600" data-id="0ocs1az6y" data-path="src/pages/BrailleToTextPage.tsx">✓</span>
                    <span data-id="nau2i3ydo" data-path="src/pages/BrailleToTextPage.tsx">Professional-grade accuracy</span>
                  </div>
                  <div className="flex items-center gap-2" data-id="fra9doswv" data-path="src/pages/BrailleToTextPage.tsx">
                    <span className="text-green-600" data-id="ifl61wusw" data-path="src/pages/BrailleToTextPage.tsx">✓</span>
                    <span data-id="p1z73i5qx" data-path="src/pages/BrailleToTextPage.tsx">Easy-to-use interface</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-center" data-id="5edixxtmt" data-path="src/pages/BrailleToTextPage.tsx">
              <Button
                onClick={handleExternalLink}
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 text-lg" data-id="2cs819dcp" data-path="src/pages/BrailleToTextPage.tsx">

                <ExternalLink className="mr-2 h-5 w-5" data-id="tu7lzdfxc" data-path="src/pages/BrailleToTextPage.tsx" />
                Open Braille Image Converter
              </Button>
              <p className="text-sm text-gray-500 mt-2" data-id="lr9p00qnd" data-path="src/pages/BrailleToTextPage.tsx">
                Opens in a new tab - Return here when finished
              </p>
            </div>

            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded" data-id="dr80puru6" data-path="src/pages/BrailleToTextPage.tsx">
              <div className="flex items-start gap-3" data-id="jgx8g47po" data-path="src/pages/BrailleToTextPage.tsx">
                <span className="text-yellow-600 text-xl" data-id="gtkfhwgxh" data-path="src/pages/BrailleToTextPage.tsx">💡</span>
                <div data-id="ol8v9649x" data-path="src/pages/BrailleToTextPage.tsx">
                  <h4 className="font-semibold text-yellow-800" data-id="xk46dpzqr" data-path="src/pages/BrailleToTextPage.tsx">Tips for better results:</h4>
                  <ul className="text-sm text-yellow-700 mt-1 space-y-1" data-id="qeq6i24i5" data-path="src/pages/BrailleToTextPage.tsx">
                    <li data-id="px2mvus9e" data-path="src/pages/BrailleToTextPage.tsx">• Ensure your Braille image is clear and well-lit</li>
                    <li data-id="l28e1qgnd" data-path="src/pages/BrailleToTextPage.tsx">• Use high resolution images when possible</li>
                    <li data-id="rood1wnz2" data-path="src/pages/BrailleToTextPage.tsx">• Make sure the Braille dots are clearly visible</li>
                    <li data-id="05nu5073t" data-path="src/pages/BrailleToTextPage.tsx">• Avoid shadows or glare on the image</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation Help */}
        <Card className="mt-8 shadow-lg border-0 bg-gradient-to-r from-purple-50 to-pink-50" data-id="yubxbwlyg" data-path="src/pages/BrailleToTextPage.tsx">
          <CardContent className="pt-6" data-id="9bv835vmo" data-path="src/pages/BrailleToTextPage.tsx">
            <div className="text-center" data-id="35d98p7u7" data-path="src/pages/BrailleToTextPage.tsx">
              <h3 className="font-semibold text-lg mb-4" data-id="f7tom4d6s" data-path="src/pages/BrailleToTextPage.tsx">Need to try other services?</h3>
              <div className="flex flex-wrap justify-center gap-4" data-id="r0d42t147" data-path="src/pages/BrailleToTextPage.tsx">
                <Link to="/text-to-braille" data-id="rxe3aj723" data-path="src/pages/BrailleToTextPage.tsx">
                  <Button variant="outline" className="flex items-center gap-2" data-id="0uaf2sjp4" data-path="src/pages/BrailleToTextPage.tsx">
                    Text to Braille
                  </Button>
                </Link>
                <Link to="/image-to-braille" data-id="ag0cqbvb4" data-path="src/pages/BrailleToTextPage.tsx">
                  <Button variant="outline" className="flex items-center gap-2" data-id="404r5azox" data-path="src/pages/BrailleToTextPage.tsx">
                    Image to Braille
                  </Button>
                </Link>
                <Link to="/about" data-id="yap9j0lwk" data-path="src/pages/BrailleToTextPage.tsx">
                  <Button variant="outline" className="flex items-center gap-2" data-id="ilyvsortt" data-path="src/pages/BrailleToTextPage.tsx">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>);

};

export default BrailleToTextPage;